<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
         header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 60vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menu li li
{
   float: left;
   position: relative;
}
#menu a
{
    float: left;
    padding: 12px 20px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}

#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
#menu ul li :last-child
{
    box-shadow: none;
}
#menu ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    text-transform: uppercase;
}
#menu ul a:hover
{
    background-color: #e04818;
}
#menu ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}
        .active,menu ul li:hover
        {
            background-color: rgb(63, 17, 189);
            border-radius: 3px;
            right: 0vh;
            top: 0px;
        }


        .card-img-top
        {
            width: 100%;
            height: 50%;
        }
        .card body
        {
          max-height: max-content;

        }
        .btn2:hover
        {
            background: transparent;
            border: 1px solid indianred;
        }
        .btn2:hover:before
        {
             width: 90%;
        }
        .row
        {
            box-sizing: border-box;
        }

        h1 

{
   font-family: 'Times New Roman', Times, serif;
   font-size: 50px;
   color: orange;
   text-shadow: 5px 8px 9px black;
   text-align: center;
}
h2
{
    font-family: 'Times New Roman', Times, serif;
   font-size: 50px;
   color:white;
   text-shadow: 5px 8px 9px black;
   text-align: center;
}
.register
{
    text-align: center;
    
}

.register a
{
    text-decoration: none;
    color: white;
    padding: 0px 20px;
    font-size: 20px;
    background: indianred;
    transition: 0.4%;
}
.register a:hover
{
    background: transparent;
    border: 1px solid indianred;
}
.container2
{
    background-color: aquamarine;
    border: 3px solid red;
    border-radius: 30px;
    text-align: center;
}
.btn1
        {
            padding: 15PX;
            margin-left: 9vh;
            background-color: rgb(81, 81, 228);
            color: black;
        }
        .btn1 a
        {
           
            
            color: black;
            text-decoration: none;
        }
        .btn1 a:hover
        {
            border: 1px solid indianred;
        }
        .btn1:hover:before
        {
             width: 90%;
        }

        .btn2
        {
            padding: 15PX;
            margin-left: 10vh;
            background-color: rgb(81, 81, 228);
            color: black;
        }
        .btn2 a
        {
            color: black;
            text-decoration: none;
        }
        .btn2 a:hover
        {
            border: 1px solid indianred;
        }
        .btn2:hover:before
        {
             width: 90%;
        }

        .btn3
        {
            padding: 15PX;
            margin-left: 5vh;
            background-color: rgb(81, 81, 228);
            color: black;
        }
        .btn3 a
        {    
            color: black;
            text-decoration: none;
        }
        .btn3 a:hover
        {
            border: 1px solid indianred;
        }
        .btn3:hover:before
        {
             width: 90%;
        }
        button:hover
        {
            background-color: #e04818;
        }
        .first
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .first img
       {
        width: 5vh;
        height: 30px;
        margin-left: -1vh;
       }
       .first img:hover
       {
        width: 8vh;
        height: 30px;
        animation-duration: 0s;
        margin-left: 1vh;

       }
       .second
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .second img
       {
        width: 4vh;
        height: 30px;
        margin-left: -1vh;
       }
       .second img:hover
       {
        width: 5vh;
        height: 30px;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .third
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .third img
       {
        width: 6vh;
        height: 30px;
        margin-left: -1.5vh;
       }
       .third img:hover
       {
        width: 8vh;
        height: 30;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .fourth
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .fourth img
       {
        width: 6vh;
        height: 50px;
        margin-left: -2vh;
       }
       .fourth img:hover
       {
        width: 8vh;
        height: 30;
      
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .popup
       {
        margin-top: -80vh;
        
       }

    </style>
</head>
<body>
    <header>    
        
        <ul id="menu">   
          <li><a href="index.php">Home</a></li>
          <li><a href="about us.php">About</a></li>
          <li><a href="courses.php">Courses</a>
              <ul>
                  <li><a href="#">Graphic Desining</a>
                      <ul>
                          <li><a href="#">logo design</a></li>
                          <li><a href="#">Banner design</a></li>
                          <li><a href="#">Poster design</a></li>
                          <li><a href="#">logo design</a></li>
                      </ul>
                  </li>
                  <li>
                      <a href="#">Web Design</a>
                      <ul>
                          <li><a href="#">HTML</a></li>
                          <li><a href="#">CSS</a></li>
                          <li><a href="#">JAVA</a></li>
                          <li><a href="#">PYTHON</a></li>
                      </ul>
                  </li>
  
                  <li>
                      <a href="#">Marketing</a>
                      <ul>
                          <li><a href="#">Email Marketing</a></li>
                          <li><a href="#">Contact Marketing</a></li>
                          <li><a href="#">Online Marketing</a></li>
                          <li><a href="#">Ofline Marketing</a></li>
                      </ul>
                  </li>
  
                  <li>
                      <a href="#">Branding</a>
                      <ul>
                          <li><a href="#">Corporate Branding</a></li>
                          <li><a href="#">Personal Branding</a></li>
                          <li><a href="#">Place Branding</a></li>
                          <li><a href="#">Digital Marketing</a></li>
                      </ul>
                  </li>
              </ul>
          </li>
          <li><a href="contact us.php">Contact</a></li>  
          <li class="active"><a href="learn&earn.php">Learn & Earn</a></li>
          <li><a href="login.php">Login here</a></li>
      </ul>                 
  </header>
    <div class="container d-flex justify-content-evenly mt-5">
    <div class="card" style="width: 18rem;">
      <img src="manshi.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Stock Marketing</h5>   
        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>

        <details>
            <summary> <a href="#" class="btn btn-primary">Read More</a></summary>
             <div class="container2">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae cumque facere quibusdam iure similique, quam deserunt perferendis iusto ab consectetur omnis sapiente quod beatae quidem quo eveniet itaque ex blanditiis provident unde reiciendis corporis iste. Est blanditiis illum ab magni facilis rerum aspernatur, facere distinctio. Animi tenetur ducimus eveniet praesentium.
             </div>
           </details>
      </div>
    </div>
    <div class="card" style="width: 18rem;">
      <img src="manshi.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Stock Marketing</h5>
        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        
        <details>
            <summary> <a href="#" class="btn btn-primary">Read More</a></summary>
             <div class="container2">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae cumque facere quibusdam iure similique, quam deserunt perferendis iusto ab consectetur omnis sapiente quod beatae quidem quo eveniet itaque ex blanditiis provident unde reiciendis corporis iste. Est blanditiis illum ab magni facilis rerum aspernatur, facere distinctio. Animi tenetur ducimus eveniet praesentium.
             </div>
           </details>
      </div>
    </div>
    <div class="card" style="width: 18rem;">
      <img src="manshi.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <h5 class="card-title">Stock Marketing</h5>
        <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
        
        <details>
            <summary> <a href="#" class="btn btn-primary">Read More</a></summary>
             <div class="container2">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae cumque facere quibusdam iure similique, quam deserunt perferendis iusto ab consectetur omnis sapiente quod beatae quidem quo eveniet itaque ex blanditiis provident unde reiciendis corporis iste. Est blanditiis illum ab magni facilis rerum aspernatur, facere distinctio. Animi tenetur ducimus eveniet praesentium.
             </div>
           </details>
      </div>
      </div>  
    </div>
</div>
<br>
<div class="container3">
    <button class="btn1"><a href="formoreknowlage.php">For More Knowladge Click Here</a></button>
    <button class="btn2"><a href="formoreknowlage.php">For More Knowladge Click Here</a></button>
    <button class="btn3"><a href="formoreknowlage.php">For More Knowladge Click Here</a></button>
</div>

<div class="popup">
    <div class="first"><a href="https://wa.me/919910755865"><img src="whatsapp logo.png" alt=""></a></div><br>
<div class="second"><a href="https://www.instagram.com/assetcompoundersacademy"><img src="Instagram-Icon.png" alt=""></a></div><br>
<div class="third"><a href="https://www.facebook.com/assetcompounders"><img src="facebook.png" alt=""></a></div><br>
<div class="fourth"><a href="https://youtube.com/@AssetCompoundersAcademy"><img src="youtube.png" alt=""></a></div>
</div>

</body>
</html>