<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="login_styl.css">
</head>
<body>
    <div class="center">
        <h1>Login</h1>
        <form action="#" method="POST" autocomplete="off">
        <div class="form">
            <input type="text" name="username" class="textfield" placeholder="Username">
            <input type="password" name="password" class="textfield" placeholder="Password">

            <div class="forgotpass"><a href="#" class="link" onclick="message()">Forget Password</a></div>

            <input type="Submit" name="login" value="Login" class="btn">

            <div class="signup">New Member ? <a href="registrationform.html" class="link">SignUp Here</a></div>
        </div>
    </div>
        </form>
</body>

<script>
    function message()
    {
        alert("Forgot Password")
    }
</script>
</html>


<?php

include("connection.php");

if(isset($_POST['login']))
{
  $username = $_POST['username'];
  $password = $_POST['password'];

  $query = "SELECT * FROM form WHERE Email ='$username' && Password = '$password'";
 $data = mysqli_query($conn, $query);

  $total = mysqli_num_rows($data);
//   echo $total;
if($total == 1)
{
$_SESSION['user_name'] = $username;
?>
<meta http-equiv = "refresh" content = "0; url = http://localhost/MANSHIKA/welcome.php"/>

<?php
}
else  
{
    echo "Login Failed";
}

}
?>