<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online quiz</title>
    <style>
        body
        {
            background-color: plum;
            padding: 0px;
            margin: 0px;

        }
        form
        {
          display: block;
        }
      .btn
        {
            background-color: blue;
            height: 4vh;
            width: 10vh;
            color: white;
            text-align: center;
            margin-left: 0vh;
            border-radius: 30px;
        }
        .btn a
        {
            color: wheat;
            text-decoration: none;
            font-size: large;
        }
    </style>
</head>
<body>
    <form name="myform">
       <h5>Q1 CPU is a ___________Device.</h5>
        <input type="radio" name="q1" value="A">Input<br>
        <input type="radio" name="q1" value="B">Processing<br>
        <input type="radio" name="q1" value="C">Output<br>
        <input type="radio" name="q1" value="D">None of these
       <h5> Q2 Keyboard is a ___________Device.</h5>
        <input type="radio" name="q2" value="A">Input<br>
        <input type="radio" name="q2" value="B">Processing<br>
        <input type="radio" name="q2" value="C">Output<br>
        <input type="radio" name="q2" value="D">None of these<br><br>
       <h5> Q3 Printer is a ___________Device.</h5>
        <input type="radio" name="q3" value="A">Input<br>
        <input type="radio" name="q3" value="B">Processing<br>
        <input type="radio" name="q3" value="C">Output<br>
        <input type="radio" name="q3" value="D">None of these<br><br>
        <input class="btn" type="button" value="Submit" onclick="check()">
    </form>
    <script>
        function check()
        {
            var q1=document.myform.q1.value;
            var q2=document.myform.q2.value;
            var q3=document.myform.q3.value;
            var count=0;
            if(q1=="B")
            {
                count++;
            }
            if(q2=="A")
            {
                count++;
            }
            if(q3=="C")
            {
                count++;
            }
            var ans = count++;
            
            var q1=document.myform.q1.value;
            var q2=document.myform.q2.value;
            var q3=document.myform.q3.value;
            var count=0;

            if(q1!="B")
            {
                count++;
            }

            if(q2!="A")
            {
                count++;
            }
            if(q3!="C")
            {
                count++;
            }
            var wrong = count++;
            alert("Your Total Right Question is : "+ans+" " + " &  Your Total Wrong Question is : " +wrong+ " "
           + " & You Total Marks is : "+ans+" " );   
        }    
    </script>
</body>
</html>

