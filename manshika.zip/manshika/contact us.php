<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *{padding: 0; margin: 0; box-sizing: border-box;}
        header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 50vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menu li li
{
   float: left;
   position: relative;
}
#menu a
{
    float: left;
    padding: 12px 30px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}

#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
#menu ul li :last-child
{
    box-shadow: none;
}
#menu ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    text-transform: uppercase;
}
#menu ul a:hover
{
    background-color: #e04818;
}
#menu ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}
        .active,menu ul li:hover
        {
            background-color: rgb(63, 17, 189);
            border-radius: 3px;
            right: 0vh;
            top: 0px;
        }
      
        .phonelogo
        {
            width: 3%;
            color: green;
        }
        .mobaillogo
        {
            width: 3%;
            padding-top: 0px;
        }
        .logoimg
        {
          width: 10%;  
          padding-left: 50px;
        }
        .shalu
        {
            height: 150px;
            width: 550px;
            background-color: white;
            color:black;
            margin: 30px;
            padding: 10px;
            position: absolute;
            left: 700px;
            top: 450px;
            text-align: center;

        }
        .juhi
        {
            height: 150px;
            width: 550px;
            background-color: white;
            color:rgb(64, 63, 131);
            margin: 30px;
            padding: 10px;
            position: absolute;
            left: 700px;
            top: 750px;
            text-align: center;

        }
        .juhi2
        {
            height: 150px;
            width: 550px;
            background-color: white;
            color:rgb(64, 63, 131);
            margin: 30px;
            padding: 10px;
            position: absolute;
            right: 700PX;
            top: 750px;
            text-align: center;

        }
        .learn
        {
            text-decoration: none;
            transition: 0.4%;
        }
        .learn a:hover
        {
            background: transparent;
            border: 1px solid rgb(75, 18, 129);
        }
        .first
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .first img
       {
        width: 5vh;
        height: 30px;
        margin-left: -1vh;
       }
       .first img:hover
       {
        width: 8vh;
        height: 30px;
        animation-duration: 0s;
        margin-left: 1vh;

       }
       .second
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .second img
       {
        width: 4vh;
        height: 30px;
        margin-left: -1vh;
       }
       .second img:hover
       {
        width: 5vh;
        height: 30px;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .third
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .third img
       {
        width: 6vh;
        height: 30px;
        margin-left: -1.5vh;
       }
       .third img:hover
       {
        width: 8vh;
        height: 30;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .fourth
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .fourth img
       {
        width: 6vh;
        height: 50px;
        margin-left: -2vh;
       }
       .fourth img:hover
       {
        width: 8vh;
        height: 30;
      
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .popup
       {
        margin-top: -125vh;
        
       }
          
          
          
    </style>
</head>
<body>
    <header>       
        <ul id="menu">   
            <li><a href="index.php">Home</a></li>
            <li><a href="about us.php">About</a></li>
            <li><a href="courses.php">Courses</a>
                <ul>
                    <li><a href="#">Graphic Desining</a>
                        <ul>
                            <li><a href="#">logo design</a></li>
                            <li><a href="#">Banner design</a></li>
                            <li><a href="#">Poster design</a></li>
                            <li><a href="#">logo design</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Web Design</a>
                        <ul>
                            <li><a href="#">HTML</a></li>
                            <li><a href="#">CSS</a></li>
                            <li><a href="#">JAVA</a></li>
                            <li><a href="#">PYTHON</a></li>
                        </ul>
                    </li>
    
                    <li>
                        <a href="#">Marketing</a>
                        <ul>
                            <li><a href="#">Email Marketing</a></li>
                            <li><a href="#">Contact Marketing</a></li>
                            <li><a href="#">Online Marketing</a></li>
                            <li><a href="#">Ofline Marketing</a></li>
                        </ul>
                    </li>
    
                    <li>
                        <a href="#">Branding</a>
                        <ul>
                            <li><a href="#">Corporate Branding</a></li>
                            <li><a href="#">Personal Branding</a></li>
                            <li><a href="#">Place Branding</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li class="active"><a href="#">Contact</a></li> 
            <li class="learn"><a href="learn&earn.php">Learn & Earn</a></li>  
            <li><a href="login.php">Login here</a></li>
        </ul>                   
    </header>
     
    <h1 style="text-align: center;  padding-top: 50px;">Contact Us</h1>
    <br><br>
    <p style="font-size: 30px; padding-left: 50px ;">Phone - 799175689 <img class="phonelogo" src="phone logo.jpg" alt=""></p> <p></p>
    <p style="font-size: 30px; padding-left: 50px;">Mobail - 799175689 <img class="mobaillogo" src="phone logo.jpg" alt=""></p>
    <br>
     <img class="logoimg" src="img logo.png" alt="">
     <p style="padding-left: 30px;">assetcompoundersacadmy</p>
     <div class="shalu">
        <h2>ADDRESS</h2>
        <p style="color: black;">CORPORATE OFFICE</p>
        Bhagwat Nagar ,    
        Patna Bihar .
    </div>
    <br><br>

    <h1 style="text-align: center;">Our Branches</h1>

    <div class="juhi">
        <h2>Mumbai</h2>     
    </div>
    <div class="juhi2">
        <h2>Gurgaon</h2>     
    </div>
    <br><br><br><br><br><br><br><br><br><br><br><br><br>      
    
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3766.0519138392665!2d72.87902367560821!3d19.28010849553242!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7b065e96af015%3A0xc18d69ac057edbd5!2sVinay%20Nagar%2C%20Hatkesh%20Udhog%20Nagar%2C%20Mira%20Road%20East%2C%20Mira%20Bhayandar%2C%20Maharashtra%20401107!5e0!3m2!1sen!2sin!4v1707209695155!5m2!1sen!2sin" width="100%" height="450" style="border:0; text-align: center;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
     
    <div class="popup">
        <div class="first"><a href="https://wa.me/919910755865"><img src="whatsapp logo.png" alt=""></a></div><br>
    <div class="second"><a href="https://www.instagram.com/assetcompoundersacademy"><img src="Instagram-Icon.png" alt=""></a></div><br>
    <div class="third"><a href="https://www.facebook.com/assetcompounders"><img src="facebook.png" alt=""></a></div><br>
    <div class="fourth"><a href="https://youtube.com/@AssetCompoundersAcademy"><img src="youtube.png" alt=""></a></div>
    </div>
</body>
</html>