<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <style>
     header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 60vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menu li li
{
   float: left;
   position: relative;
}
#menu a
{
    float: left;
    padding: 10px 20px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}
#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
     
        .sample
        {
          text-align: center;
          margin-top:30%;
        }
    
   </style>
</head>
<body>
<header>    
        
          <ul id="menu">   
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="about us.php">About</a></li>
            <li><a href="courses.php">Courses</a>
                <ul>
                    <li><a href="#">Graphic Desining</a>
                        <ul>
                            <li><a href="#">logo design</a></li>
                            <li><a href="#">Banner design</a></li>
                            <li><a href="#">Poster design</a></li>
                            <li><a href="#">logo design</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Web Design</a>
                        <ul>
                            <li><a href="#">HTML</a></li>
                            <li><a href="#">CSS</a></li>
                            <li><a href="#">JAVA</a></li>
                            <li><a href="#">PYTHON</a></li>
                        </ul>
                    </li>
    
                    <li>
                        <a href="#">Marketing</a>
                        <ul>
                            <li><a href="#">Email Marketing</a></li>
                            <li><a href="#">Contact Marketing</a></li>
                            <li><a href="#">Online Marketing</a></li>
                            <li><a href="#">Ofline Marketing</a></li>
                        </ul>
                    </li>
    
                    <li>
                        <a href="#">Branding</a>
                        <ul>
                            <li><a href="#">Corporate Branding</a></li>
                            <li><a href="#">Personal Branding</a></li>
                            <li><a href="#">Place Branding</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li><a href="contact us.php">Contact</a></li>  
            <li class="learn"><a href="learn&earn.php">Learn & Earn</a></li>
            <li><a href="logout.php">logout</a></li>
        </ul>                 

    </header>
</body>
</html>

<?php
include("connection.php");
error_reporting(0);

session_start();
if(!isset($_SESSION['user_name']))
{
    ?>
<meta http-equiv = "refresh" content = "0; url = http://localhost/manshika/login.php"/>

<?php
}
?>
<h2 class="sample">Welcome To This Website: <span style="color: orange" ><?php echo $_SESSION
['user_name']; ?></span>
</h2>
<a href="logout.php"><input type="submit" name="" value="LogOut" style="background: blue; color: white; height: 35px; width: 100px; margin-top: 20px;
font-size: 18px; border: 0; border-radius: 5px;"></a>

