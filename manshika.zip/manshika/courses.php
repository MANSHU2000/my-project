<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menuhed #menuhed ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menuhed
{
    width: 900px;
    margin-left: 50vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menuhed:before,
#menuhed:after
{
    content: '';
    display: table;
}
#menuhed:after
{
    clear: both;
}
#menuhed li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menuhed li li
{
   float: left;
   position: relative;
}
#menuhed a
{
    float: left;
    padding: 12px 30px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}

#menuhed li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menuhed ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menuhed li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menuhed ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menuhed ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
#menuhed ul li :last-child
{
    box-shadow: none;
}
#menuhed ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    text-transform: uppercase;
}
#menuhed ul a:hover
{
    background-color: #e04818;
}
#menuhed ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}

.active,menu ul li:hover
        {
            background-color: rgb(63, 17, 189);
            border-radius: 3px;
            right: 0vh;
            top: 0px;
        }




        .container
        {
            width: 100%;
            height: 30px;
            border: 3px solid black;
            background-color: blueviolet;
            text-align: center  ;
            color: aquamarine;
            text-size-adjust: 80px;
            
        }
        
        .card-img-top
        {
            width: 100%;
            height: 50%;
        }
        .card body
        {
          max-height: max-content;

        }
        .card-title
        {
            text-align: center;
            color: brown;
        }
        .btn2
        {
            padding: 15PX;
            margin-left: 70vh;
            background-color: rgb(81, 81, 228);
            color: black;
          
        }
        .btn2 a
        {
           
            
            background-color: rgb(81, 81, 228);
            color: white;
            text-decoration: none;
        }
        .btn2:hover
        {
            background: transparent;
            background: red;
        }
        .btn2 a:hover
        {
            background: transparent;
            background: red;
        }
        .btn2:hover:before
        {
             width: 90%;
        }
        .row
        {
            box-sizing: border-box;
        }
        h1 

        {
           font-family: 'Times New Roman', Times, serif;
           font-size: 50px;
           color: orange;
           text-shadow: 5px 8px 9px black;
           text-align: center;
        }
        h2
        {
            font-family: 'Times New Roman', Times, serif;
           font-size: 50px;
           color:white;
           text-shadow: 5px 8px 9px black;
           text-align: center;
        }
        details summary
        {
            text-align: center;
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 0vh;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}

#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li li
{
   
   position: relative;
}
#menu a
{
    
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: rgb(88, 25, 189);

}
#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 60vh;
    left: 20vh;
    z-index: 1;
   background-color: aqua;
    color: #fafafa;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}

#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 hwb(0 91% 7%), 0 2px 0 #666;
}
#menu ul li :last-child
{
    box-shadow: none;
}
#menu ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    /* text-transform: uppercase; */
}
#menu ul a:hover
{
    background-color: #e04818;
}
#menu ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}








#menu2 #menu2 ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu2
{
    width: 900px;
    margin-left: 0vh;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}

#menu2:before,
#menu2:after
{
    content: '';
    display: table;
}
#menu2:after
{
    clear: both;
}
#menu2 li li
{
   
   position: relative;
}
#menu2 a
{
    
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: rgb(88, 25, 189);

}
#menu2 li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu2 ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 145vh;
    left: 20vh;
    z-index: 1;
   background-color: aqua;
    color: #fafafa;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}

#menu2 li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu2 ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu2 ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 hwb(0 91% 7%), 0 2px 0 #666;
}
#menu2 ul li :last-child
{
    box-shadow: none;
}
#menu2 ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    /* text-transform: uppercase; */
}
#menu2 ul a:hover
{
    background-color: #e04818;
}
#menu2 ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}





#menu3 #menu3 ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu3
{
    width: 900px;
    margin-left: 0vh;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}

#menu3:before,
#menu3:after
{
    content: '';
    display: table;
}
#menu3:after
{
    clear: both;
}
#menu3 li li
{
   
   position: relative;
}
#menu3 a
{
    
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: rgb(88, 25, 189);

}
#menu3 li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu3 ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 225vh;
    left: 20vh;
    z-index: 1;
   background-color: aqua;
    color: #fafafa;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}

#menu3 li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu3 ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu3 ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 hwb(0 91% 7%), 0 2px 0 #666;
}
#menu3 ul li :last-child
{
    box-shadow: none;
}
#menu3 ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    /* text-transform: uppercase; */
}
#menu3 ul a:hover
{
    background-color: #e04818;
}
#menu3 ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}






#menu4 #menu3 ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu4
{
    width: 900px;
    margin-left: 0vh;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}

#menu4:before,
#menu4:after
{
    content: '';
    display: table;
}
#menu4:after
{
    clear: both;
}
#menu4 li li
{
   
   position: relative;
}
#menu4 a
{
    
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: rgb(88, 25, 189);

}
#menu4 li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu4 ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 310vh;
    left: 20vh;
    z-index: 1;
   background-color: aqua;
    color: #fafafa;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}

#menu4 li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu4 ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu4 ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 hwb(0 91% 7%), 0 2px 0 #666;
}
#menu4 ul li :last-child
{
    box-shadow: none;
}
#menu4 ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    /* text-transform: uppercase; */
}
#menu4 ul a:hover
{
    background-color: #e04818;
}
#menu4 ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}



.first
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .first img
       {
        width: 5vh;
        height: 30px;
        margin-left: -1vh;
       }
       .first img:hover
       {
        width: 8vh;
        height: 30px;
        animation-duration: 0s;
        margin-left: 1vh;

       }
       .second
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .second img
       {
        width: 4vh;
        height: 30px;
        margin-left: -1vh;
       }
       .second img:hover
       {
        width: 5vh;
        height: 30px;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .third
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .third img
       {
        width: 6vh;
        height: 30px;
        margin-left: -1.5vh;
       }
       .third img:hover
       {
        width: 8vh;
        height: 30;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .fourth
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .fourth img
       {
        width: 6vh;
        height: 50px;
        margin-left: -2vh;
       }
       .fourth img:hover
       {
        width: 8vh;
        height: 30;
      
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .popup
       {
        margin-top: -340vh;
        
       }



    </style>
</head>
<body>
    <header>    
        
        <ul id="menuhed">   
          <li><a href="index.PHP">Home</a></li>
          <li><a href="about us.PHP">About</a></li>
          <li class="active"><a href="#">Courses</a>
              <ul>
                  <li><a href="logodigin.html">Graphic Desining</a>
                      <ul>
                          <li><a href="logodigin.html">logo design</a></li>
                          <li><a href="logodigin.html">Banner design</a></li>
                          <li><a href="logodigin.html">Poster design</a></li>
                          <li><a href="logodigin.html">logo design</a></li>
                      </ul>
                  </li>
                  <li>
                      <a href="logodigin.html">Web Design</a>
                      <ul>
                          <li><a href="logodigin.html">HTML</a></li>
                          <li><a href="logodigin.html">CSS</a></li>
                          <li><a href="logodigin.html">JAVA</a></li>
                          <li><a href="logodigin.html">PYTHON</a></li>
                      </ul>
                  </li>
  
                  <li>
                      <a href="logodigin.html">Marketing</a>
                      <ul>
                          <li><a href="logodigin.html">Email Marketing</a></li>
                          <li><a href="logodigin.html">Contact Marketing</a></li>
                          <li><a href="logodigin.html">Online Marketing</a></li>
                          <li><a href="logodigin.html">Ofline Marketing</a></li>
                      </ul>
                  </li>
  
                  <li>
                      <a href="logodigin.html">Branding</a>
                      <ul>
                          <li><a href="logodigin.html">Corporate Branding</a></li>
                          <li><a href="logodigin.html">Personal Branding</a></li>
                          <li><a href="logodigin.html">Place Branding</a></li>
                          <li><a href="logodigin.html">Digital Marketing</a></li>
                      </ul>
                  </li>
              </ul>
          </li>
          <li><a href="contact us.php">Contact</a></li>  
          <li class="learn"><a href="learn&earn.php">Learn & Earn</a></li>
          <li><a href="login.php">Login here</a></li>
      </ul>                 

  </header>
  <br>

    <div class="container">
        <details>
            <summary>What Is Graphic Design</summary>
            <p style="color: black;"> <b>Graphic design is the practice of composing and arranging the visual elements of a project</b></p>
        </details>
    </div>
    <br><br><br>
    <div class="row">
        <div class="col-lg-3 border border-3 ;">
            <ul id="menu">   
                <li><a href="#">Graphic Design</a>
                    <ul>
                        <li><a href="logodigin.html">logo design</a></li>
                        <li><a href="logodigin.html">Banner design</a></li>
                        <li><a href="logodigin.html">Poster design</a></li>
                        <li><a href="logodigin.html">logo design</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="about us.html">Web Design</a>
                    <ul>
                        <li><a href="logodigin.html">HTML</a></li>
                        <li><a href="logodigin.html">CSS</a></li>
                        <li><a href="logodigin.html">JAVA</a></li>
                        <li><a href="logodigin.html">PYTHON</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="logodigin.html">Marketing</a>
                    <ul>
                        <li><a href="logodigin.html">Email Marketing</a></li>
                        <li><a href="logodigin.html">Contact Marketing</a></li>
                        <li><a href="logodigin.html">Online Marketing</a></li>
                        <li><a href="logodigin.html">Ofline Marketing</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="contact us.html">Branding</a>
                    <ul>
                        <li><a href="logodigin.html">Corporate Branding</a></li>
                        <li><a href="logodigin.html">Personal Branding</a></li>
                        <li><a href="logodigin.html">Place Branding</a></li>
                        <li><a href="logodigin.html">Digital Marketing</a></li>
                    </ul></li>  
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Banner design</b></h5>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    
           <details>
            <summary> <a href="#" class="btn btn-primary">Read</a></summary>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
           </details>
          </div>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Poster design</b></h5>
            <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            
            <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
          </div>
          
        </div>
        <div class="col-lg-3 border border-3;">
            <img src="manshi.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><b>logo design</b></h5>
              <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
            </div>
            
          </div>
          
    </div>
    
    <br>
    <button class="btn2"><a href="login.php"><b>Join My class</b></a></button>
    <br><br>
    
    <div class="container">
        <details>
            <summary>What Is Web Design</summary>
            <p style="color: black;"> <b>Graphic design is the practice of composing and arranging the visual elements of a project</b></p>
        </details>
    </div>
    <br><br><br>
    <div class="row">
        <div class="col-lg-3 border border-3 ;">
            <ul id="menu2">   
                <li><a href="#">Graphic Design</a>
                    <ul>
                        <li><a href="logodigin.html">logo design</a></li>
                        <li><a href="logodigin.html">Banner design</a></li>
                        <li><a href="logodigin.html">Poster design</a></li>
                        <li><a href="logodigin.html">logo design</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="about us.html">Web Design</a>
                    <ul>
                        <li><a href="logodigin.html">HTML</a></li>
                        <li><a href="logodigin.html">CSS</a></li>
                        <li><a href="logodigin.html">JAVA</a></li>
                        <li><a href="logodigin.html">PYTHON</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="logodigin.html">Marketing</a>
                    <ul>
                        <li><a href="logodigin.html">Email Marketing</a></li>
                        <li><a href="logodigin.html">Contact Marketing</a></li>
                        <li><a href="logodigin.html">Online Marketing</a></li>
                        <li><a href="logodigin.html">Ofline Marketing</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="contact us.html">Branding</a>
                    <ul>
                        <li><a href="logodigin.html">Corporate Branding</a></li>
                        <li><a href="logodigin.html">Personal Branding</a></li>
                        <li><a href="logodigin.html">Place Branding</a></li>
                        <li><a href="logodigin.html">Digital Marketing</a></li>
                    </ul></li>  
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Banner design</b></h5>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    
           <details>
            <summary> <a href="#" class="btn btn-primary">Read</a></summary>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
           </details>
          </div>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Poster design</b></h5>
            <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            
            <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
          </div>
          
        </div>
        <div class="col-lg-3 border border-3;">
            <img src="manshi.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><b>logo design</b></h5>
              <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
            </div>
            
          </div>
          
    </div>
    <br>
    <button class="btn2"><a href="login.php"><b>Join My Class</b></a></button>
    <br><br>

    <div class="container">
        <details>
            <summary>What Is Graphic Design</summary>
            <p style="color: black;"> <b>Graphic design is the practice of composing and arranging the visual elements of a project</b></p>
        </details>
    </div>
    <br><br><br>
    <div class="row">
        <div class="col-lg-3 border border-3 ;">
            <ul id="menu3">   
                <li><a href="#">Graphic Design</a>
                    <ul>
                        <li><a href="logodigin.html">logo design</a></li>
                        <li><a href="logodigin.html">Banner design</a></li>
                        <li><a href="logodigin.html">Poster design</a></li>
                        <li><a href="logodigin.html">logo design</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="about us.html">Web Design</a>
                    <ul>
                        <li><a href="logodigin.html">HTML</a></li>
                        <li><a href="logodigin.html">CSS</a></li>
                        <li><a href="logodigin.html">JAVA</a></li>
                        <li><a href="logodigin.html">PYTHON</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="logodigin.html">Marketing</a>
                    <ul>
                        <li><a href="logodigin.html">Email Marketing</a></li>
                        <li><a href="logodigin.html">Contact Marketing</a></li>
                        <li><a href="logodigin.html">Online Marketing</a></li>
                        <li><a href="logodigin.html">Ofline Marketing</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="contact us.html">Branding</a>
                    <ul>
                        <li><a href="logodigin.html">Corporate Branding</a></li>
                        <li><a href="logodigin.html">Personal Branding</a></li>
                        <li><a href="logodigin.html">Place Branding</a></li>
                        <li><a href="logodigin.html">Digital Marketing</a></li>
                    </ul></li>  
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Banner design</b></h5>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    
           <details>
            <summary> <a href="#" class="btn btn-primary">Read</a></summary>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
           </details>
          </div>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Poster design</b></h5>
            <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            
            <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
          </div>
          
        </div>
        <div class="col-lg-3 border border-3;">
            <img src="manshi.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><b>logo design</b></h5>
              <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
            </div>
            
          </div>
          
    </div>
    <br>
    <button class="btn2"><a href="login.php"><b>Join My Class</b></a></button>
    <br><br>

    <div class="container">
        <details>
            <summary>What Is Graphic Design</summary>
            <p style="color: black;"> <b>Graphic design is the practice of composing and arranging the visual elements of a project</b></p>
        </details>
    </div>
    <br><br><br>
    <div class="row">
        <div class="col-lg-3 border border-3 ;">
            <ul id="menu4">   
                <li><a href="#">Graphic Design</a>
                    <ul>
                        <li><a href="logodigin.html">logo design</a></li>
                        <li><a href="logodigin.html">Banner design</a></li>
                        <li><a href="logodigin.html">Poster design</a></li>
                        <li><a href="logodigin.html">logo design</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="about us.html">Web Design</a>
                    <ul>
                        <li><a href="logodigin.html">HTML</a></li>
                        <li><a href="logodigin.html">CSS</a></li>
                        <li><a href="logodigin.html">JAVA</a></li>
                        <li><a href="logodigin.html">PYTHON</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="logodigin.html">Marketing</a>
                    <ul>
                        <li><a href="logodigin.html">Email Marketing</a></li>
                        <li><a href="logodigin.html">Contact Marketing</a></li>
                        <li><a href="logodigin.html">Online Marketing</a></li>
                        <li><a href="logodigin.html">Ofline Marketing</a></li>
                    </ul>
                </li>
                <br>
                <li><a href="contact us.html">Branding</a>
                    <ul>
                        <li><a href="logodigin.html">Corporate Branding</a></li>
                        <li><a href="logodigin.html">Personal Branding</a></li>
                        <li><a href="logodigin.html">Place Branding</a></li>
                        <li><a href="logodigin.html">Digital Marketing</a></li>
                    </ul></li>  
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Banner design</b></h5>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    
           <details>
            <summary> <a href="#" class="btn btn-primary">Read</a></summary>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
           </details>
          </div>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><b>Poster design</b></h5>
            <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            
            <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
          </div>
          
        </div>
        <div class="col-lg-3 border border-3;">
            <img src="manshi.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title"><b>logo design</b></h5>
              <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
              <details>
                <summary> <a href="#" class="btn btn-primary">Read</a></summary>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nostrum dolore veritatis molestias temporibus ut laboriosam eaque, iusto quaerat doloremque quisquam. Dolore, explicabo. Laborum, maxime. Rerum eum perferendis</p>
               </details>
            </div>
            
          </div>
          
    </div>
    <br>
    <button class="btn2"><a href="login.php"><b>Join My Class</b></a></button>
    <br><br>

    <div class="popup">
        <div class="first"><a href="https://wa.me/919910755865"><img src="whatsapp logo.png" alt=""></a></div><br>
    <div class="second"><a href="https://www.instagram.com/assetcompoundersacademy"><img src="Instagram-Icon.png" alt=""></a></div><br>
    <div class="third"><a href="https://www.facebook.com/assetcompounders"><img src="facebook.png" alt=""></a></div><br>
    <div class="fourth"><a href="https://youtube.com/@AssetCompoundersAcademy"><img src="youtube.png" alt=""></a></div>
    </div>
    

</body>
</html>