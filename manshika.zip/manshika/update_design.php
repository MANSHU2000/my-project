<?php
include("connection.php");
session_start();
error_reporting(0);
$id = $_GET['id'];

$userprofile = $_SESSION['user_name'];
if($userprofile == true)
{

}
else
{
    ?>
    <meta http-equiv = "refresh" content = "0; url = http://localhost/sapna/login.php"/>
    <?php
}

$query = "SELECT * FROM FORM where ID_NO= '$id'";
$data = mysqli_query($conn, $query);

$total = mysqli_num_rows($data);
$result = mysqli_fetch_assoc($data);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Updait</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <form action="#" method="POST">
        <div class="title">
           Update Student Details
        </div>
        <div class="form">
            <div class="input_field">
                <label>First Name</label>
                <input type="text" value="<?php echo $result['Fname'];?>" class="input" name="fname" required>
                
            </div>
            <div class="input_field">
                <label>Last Name</label>
                <input type="text" value="<?php echo $result['Lname'];?>"  class="input" name="lname" required>
                
            </div>
            <div class="input_field">
                <label>Password</label>
                <input type="password" value="<?php echo $result['Password'];?>"  class="input" name="password" required>
                
            </div>
            <div class="input_field">
                <label>confirm_password</label>
                <input type="text" value="<?php echo $result['Confirm_Password'];?>" class="input" name="conpassword" required>
                
            </div>
            <div class="input_field">
                <label>Gender</label>
               <div class="custome_select">

               <select name="gender" required>
               <option value="">Select</option>

               <option value="mail" <?php if($result['Gender'] == 'mail') { echo "selected";}?> >Male</option>
               <option value="female" <?php if($result['Gender'] == 'female') { echo "selected";}?>>Female</option>
               </select>
               </div>
                
            </div>
            <div class="input_field">
                <label>Email Address</label>
                <input type="email" value="<?php echo $result['Email'];?>" class="input" name="email" required>
                
            </div>
            <div class="input_field">
                <label>Phone Number</label>
                <input type="text" value="<?php echo $result['Phone'];?>" class="input" name="phone" required>
                
            </div>
            <div class="input_field">
                <label>Address</label>
                <textarea class="textarea" name="address" required> <?php echo $result['Address'];?></textarea>
            </div>

            <div class="input_field">
                <label class="check">
                    <input type="checkbox" required>
                    <span class="checkmark"></span>
                </label>
                <p>Agree to Term And Conditions</p>
            </div>

            <div class="input_field">
                <input type="submit" value="Update Details" class="btn" name="update">
            </div>
        </div>
        </form>
    </div>
</body>
</html>

<?php
if($_POST['update'])

{
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $pwd   = $_POST['password'];
  $cpwd  = $_POST['conpassword'];
  $gender= $_POST['gender'];
  $email= $_POST['email'];
  $phone = $_POST['phone'];
  $add   = $_POST['address'];

$query = "UPDATE form SET Fname='$fname',Lname='$lname',Password='$pwd',
Confirm_Password='$cpwd',Gender='$gender',Email='$email',Phone='$phone',Address='$add' Where ID_NO='$id'";
$data = mysqli_query($conn,$query);

if($data)
{
    echo "Record Updated";
}
else
{
    echo "failed";
}

}

?>
