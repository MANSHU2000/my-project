<?php
session_start();
// echo "Welcome ".$_SESSION['user_name']; 
?>


<html>
    <head>
        <title>Display</title>
        <style>
            body
            {
                background: #d071f9;
            }
            table
            {
                background-color: white;
            }
             a
            {
                
                text-decoration:none;
                text-align:center;
            }
        </style>
    </head>
</html>
<?php
include("connection.php");
error_reporting(0);

$userprofile = $_SESSION['user_name'];
if($userprofile == true)
{

}
else
{
    ?>
    <meta http-equiv = "refresh" content = "0; url =http://localhost/sapna/display.php"/>
    <?php
}


$query = "SELECT * FROM FORM";
$data = mysqli_query($conn, $query);

$total = mysqli_num_rows($data);



// echo $total;

if($total != 0)
{
    ?>
   
   <h2 align="center"><mark>Displaying All Records</mark></h2>
   <center>
    <table border="1" cellspacing="7" width="100%">
        <tr>
        <th width="5%">ID</th>
        <th width="10%">First Name</th>
        <th width="10%">Last Name</th>
        <th width="5%">Password</th>
        <th width="5%">Confirm Password</th>
        <th width="5%">Gender</th>
        <th width="10%">Email</th>
        <th width="10%">Phone Number</th>
        <th width="10%">Cast</th>
        <th width="20%">Address</th>
        <th width="10%">Oprations</th>
        </tr>

    <?php
  
   while($result = mysqli_fetch_assoc($data))
   {
    echo "<tr>
             <td>".$result['ID_NO']."</td> 
             <td>".$result['Fname']."</td>
             <td>".$result['Lname']."</td>
             <td>".$result['Password']."</td>
             <td>".$result['Confirm_Password']."</td>
             <td>".$result['Gender']."</td>
             <td>".$result['Email']."</td>
             <td>".$result['Phone']."</td>
             <td>".$result['Cast']."</td>
             <td>".$result['Address']."</td>
             
             <td><a href='update_design.php?id=$result[ID_NO]'>Update</a></td>
          </tr>
          ";
   }
}
else
{
    echo "no record found";
}
?>
 </table>
</center>
<a href="logout.php"><input type="submit" name="" value="LogOut" style="background: blue; color: white; height: 35px; width: 100px; margin-top: 20px;
font-size: 18px; border: 0; border-radius: 5px;"></a>
