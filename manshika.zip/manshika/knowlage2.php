<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
         body
        {
            background-color:gainsboro;
            padding: 0px;
            margin: 0px;
        }
         header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 60vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menu li li
{
   float: left;
   position: relative;
}
#menu a
{
    float: left;
    padding: 12px 19px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}

#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
#menu ul li :last-child
{
    box-shadow: none;
}
#menu ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    text-transform: uppercase;
}
#menu ul a:hover
{
    background-color: #e04818;
}
#menu ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}
        .active,menu ul li:hover
        {
            background-color: rgb(63, 17, 189);
            border-radius: 3px;
            right: 0vh;
            top: 0px;
        }

        .heading1::first-letter
        {
          font-family:'Times New Roman', Times, serif;
          font-size: 50px;
          color:orange;
          text-shadow: 3px 3px px black;
        }
        .heading2::first-line
        {
          font-family:'Times New Roman', Times, serif;
          font-size: 50px;
          color:rgb(8, 67, 90);
          text-shadow: 3px 3px 3px black;
        }
        .heading::first-line
        {
          font-family:'Times New Roman', Times, serif;
          font-size: 44px;
          color: rgb(151, 53, 53);
          text-shadow: 3px 3px 3px black;
        }
        .btn5{
            background-color: blue;
            height: 5vh;
            width: 20vh;
            color: white;
            text-align: center;
            margin-left: 65vh;
            border-radius: 30px;
        }
        .btn5 a
        {
            color: wheat;
            text-decoration: none;
            font-size: large;
        }
        
    </style>
</head>
<body>
    <header>    
        
        <ul id="menu">   
          <li><a href="#">Home</a></li>
          <li><a href="about us.html">About</a></li>
          <li><a href="logodigin.html">Courses</a>
              <ul>
                  <li><a href="logodigin.html">Graphic Desining</a>
                      <ul>
                          <li><a href="logodigin.html">logo design</a></li>
                          <li><a href="logodigin.html">Banner design</a></li>
                          <li><a href="logodigin.html">Poster design</a></li>
                          <li><a href="logodigin.html">logo design</a></li>
                      </ul>
                  </li>
                  <li>
                      <a href="logodigin.html">Web Design</a>
                      <ul>
                          <li><a href="logodigin.html">HTML</a></li>
                          <li><a href="logodigin.html">CSS</a></li>
                          <li><a href="logodigin.html">JAVA</a></li>
                          <li><a href="logodigin.html">PYTHON</a></li>
                      </ul>
                  </li>
  
                  <li>
                      <a href="logodigin.html">Marketing</a>
                      <ul>
                          <li><a href="logodigin.html">Email Marketing</a></li>
                          <li><a href="logodigin.html">Contact Marketing</a></li>
                          <li><a href="logodigin.html">Online Marketing</a></li>
                          <li><a href="logodigin.html">Ofline Marketing</a></li>
                      </ul>
                  </li>
  
                  <li>
                      <a href="logodigin.html">Branding</a>
                      <ul>
                          <li><a href="logodigin.html">Corporate Branding</a></li>
                          <li><a href="logodigin.html">Personal Branding</a></li>
                          <li><a href="logodigin.html">Place Branding</a></li>
                          <li><a href="logodigin.html">Digital Marketing</a></li>
                      </ul>
                  </li>
              </ul>
          </li>
          <li><a href="contact us.html">Contact</a></li>  
          <li class="active"><a href="#">Learn & Earn</a></li>
      </ul>                 
  </header>
  <br>
  <details style="text-align: center; background-color: rgb(68, 97, 97);">
    <summary style="font-size: 25px;">Courses name</summary>
       <h4 style="color: brown;">Web Development</h4>
  </details>


  <div class="container d-flex justify-content-evenly mt-5">
    <!-- <div class="card" style="width: 18rem;">
        <video controls>
            <source src="VIDEO.mp4">
        </video>
      <div class="card-body">
        <h5 class="card-title">Stock Marketing</h5>   
        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>

        <details>
            <summary> <a href="#" class="btn btn-primary">Read More</a></summary>
             <div class="container2">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae cumque facere quibusdam iure similique, quam deserunt perferendis iusto ab consectetur omnis sapiente quod beatae quidem quo eveniet itaque ex blanditiis provident unde reiciendis corporis iste. Est blanditiis illum ab magni facilis rerum aspernatur, facere distinctio. Animi tenetur ducimus eveniet praesentium.
             </div>
           </details>
      </div>
    </div> -->
    <div class="card" style="width: 25rem; height: 100%; ">
        <br>
        <h2 style="text-align: center; color: chocolate;">Courses Start Date </h2>
        <br>
        <h3 style="text-align: center;">17/02/2024</h3>
        <br>
        <h2 style="text-align: center; color: chocolate;">Courses Duration </h2>
        <br>
        <h3 style="text-align: center;"> 15-Days</h3>
      <h2 style="color: blue;">Mentor:</h2> 
    </div>
    <div class="card" style="width: 25rem;">
        <video controls>
            <source src="VIDEO.mp4">
        </video>
      </div>  
    </div>
</div>

<div class="container d-flex justify-content-evenly mt-5">
    <!-- <div class="card" style="width: 18rem;">
        <video controls>
            <source src="VIDEO.mp4">
        </video>
      <div class="card-body">
        <h5 class="card-title">Stock Marketing</h5>   
        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>

        <details>
            <summary> <a href="#" class="btn btn-primary">Read More</a></summary>
             <div class="container2">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae cumque facere quibusdam iure similique, quam deserunt perferendis iusto ab consectetur omnis sapiente quod beatae quidem quo eveniet itaque ex blanditiis provident unde reiciendis corporis iste. Est blanditiis illum ab magni facilis rerum aspernatur, facere distinctio. Animi tenetur ducimus eveniet praesentium.
             </div>
           </details>
      </div>
    </div> -->
    <div class="card" style="width: 25rem; height: 100%; ">
        <h1 class="heading1" style="text-align: center;">Courses content</h1>
    <h3 class="heading2">Chapter-1</h3>
    <h5>The ::first-letter pseudo-element</h5>
    <h3 class="heading2">Chapter-2</h3>
    <h5>The simple tooltip hover</h5>
    <h5 class="heading2">Chapter-3</h5>
    <h5>:focus pseudo-class</h5>  
    </div>
    <div class="card" style="width: 25rem;">
        <h1 class="heading1" style="text-align: center;">Winning Prizes</h1>
        <h3 class="heading" style="text-align: center;">First Winner</h3>
        <p style="text-align: center; color: darkgoldenrod;">The winner of the first prize will get Rs 599.</p>
        <h3 class="heading" style="text-align: center;">Second Winner</h3>
        <p style="text-align: center; color: darkgoldenrod;">The winner of the first prize will get Rs 399.</p>
        <h3 class="heading" style="text-align: center;">Third Winner</h3>
        <p style="text-align: center; color: darkgoldenrod;">The winner of the first prize will get Rs 299.</p> 
      </div>  
    </div>
</div>
<br>

<button class="btn5"><a href="registrationform.html"><b>Enroll Now</b></a></button>
</body>
</html>