<?php
session_start();

session_unset();
?>
<meta http-equiv = "refresh" content = "0; url =http://localhost/MANSHIKA/login.php"/>
<?php
?>