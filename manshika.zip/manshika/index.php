<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple landing page using html css in hindi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style type="text/css">
        header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 60vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menu li li
{
   float: left;
   position: relative;
}
#menu a
{
    float: left;
    padding: 10px 20px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}

#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
#menu ul li :last-child
{
    box-shadow: none;
}
#menu ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    text-transform: uppercase;
}
#menu ul a:hover
{
    background-color: #e04818;
}
#menu ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}
        .active,menu ul li:hover
        {
            background-color: rgb(63, 17, 189);
            border-radius: 3px;
            right: 0vh;
            top: 0px;
        }
      
        .card-img-top
        {
            width: 100%;
            height: 50%;
        }
        .card body
        {
          max-height: max-content;

        }
        .btn2:hover
        {
            background: transparent;
            border: 1px solid indianred;
        }
        .btn2:hover:before
        {
             width: 90%;
        }
        .row
        {
            box-sizing: border-box;
        }
        h1 

        {
           font-family: 'Times New Roman', Times, serif;
           font-size: 50px;
           color: orange;
           text-shadow: 5px 8px 9px black;
           text-align: center;
        }
        h2
        {
            font-family: 'Times New Roman', Times, serif;
           font-size: 50px;
           color:white;
           text-shadow: 5px 8px 9px black;
           text-align: center;
        }
        .register
        {
            text-align: center;
            
        }
  
        .register a
        {
            text-decoration: none;
            color: white;
            padding: 0px 20px;
            font-size: 20px;
            background: indianred;
            transition: 0.4%;
        }
        .register a:hover
        {
            background: transparent;
            border: 1px solid indianred;
        }
        /* .learn
        {
            background: rgb(14, 194, 201);
            text-decoration: none;
            transition: 0.4%;
        } */
        .learn a:hover
        {
            background: transparent;
            border: 1px solid rgb(75, 18, 129);
        }

        .first
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .first img
       {
        width: 5vh;
        height: 30px;
        margin-left: -1vh;
       }
       .first img:hover
       {
        width: 8vh;
        height: 30px;
        animation-duration: 0s;
        margin-left: 1vh;

       }
       .second
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .second img
       {
        width: 4vh;
        height: 30px;
        margin-left: -1vh;
       }
       .second img:hover
       {
        width: 5vh;
        height: 30px;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .third
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .third img
       {
        width: 6vh;
        height: 30px;
        margin-left: -1.5vh;
       }
       .third img:hover
       {
        width: 8vh;
        height: 30;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .fourth
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .fourth img
       {
        width: 6vh;
        height: 50px;
        margin-left: -2vh;
       }
       .fourth img:hover
       {
        width: 8vh;
        height: 30;
      
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .popup
       {
        margin-top: -74vh;
        
       }

        
                
    </style>
</head>
<body>
    <header>    
        
          <ul id="menu">   
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="about us.php">About</a></li>
            <li><a href="courses.php">Courses</a>
                <ul>
                    <li><a href="#">Graphic Desining</a>
                        <ul>
                            <li><a href="#">logo design</a></li>
                            <li><a href="#">Banner design</a></li>
                            <li><a href="#">Poster design</a></li>
                            <li><a href="#">logo design</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="#">Web Design</a>
                        <ul>
                            <li><a href="#">HTML</a></li>
                            <li><a href="#">CSS</a></li>
                            <li><a href="#">JAVA</a></li>
                            <li><a href="#">PYTHON</a></li>
                        </ul>
                    </li>
    
                    <li>
                        <a href="#">Marketing</a>
                        <ul>
                            <li><a href="#">Email Marketing</a></li>
                            <li><a href="#">Contact Marketing</a></li>
                            <li><a href="#">Online Marketing</a></li>
                            <li><a href="#">Ofline Marketing</a></li>
                        </ul>
                    </li>
    
                    <li>
                        <a href="#">Branding</a>
                        <ul>
                            <li><a href="#">Corporate Branding</a></li>
                            <li><a href="#">Personal Branding</a></li>
                            <li><a href="#">Place Branding</a></li>
                            <li><a href="#">Digital Marketing</a></li>
                        </ul>
                    </li>
                </ul>
            </li>
            <li><a href="contact us.php">Contact</a></li>  
            <li class="learn"><a href="learn&earn.php">Learn & Earn</a></li>
            <li><a href="login.php">Login here</a></li>
        </ul>                 

    </header>
    <br><br>
    
      <br>
    <div class="row">
        <div class="col-lg-3 border border-3 ;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Stock Marketing</h5>   
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>

            <a href="#" class="btn btn-primary">Read</a>
          </div>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Stock Marketing</h5>
            <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis, cum! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            
            <a href="#" class="btn btn-primary">Read</a>
          </div>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="manshi.jpeg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Stock Marketing</h5>
            <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            
            <a href="#" class="btn btn-primary">Read</a>
          </div>
          
        </div>
        <div class="col-lg-3 border border-3;">
            <img src="manshi.jpeg" class="card-img-top" alt="...">
            <div class="card-body">
              <h5 class="card-title">Stock Marketing</h5>
              <p class="card-text"> Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero, sapiente! Some quick example text to build on the card title and make up the bulk of the card's content.</p>
         
              <a href="#" class="btn btn-primary">Read</a>
            </div>
            
          </div>
          
    </div>
    <div class="popup">
        <div class="first"><a href="https://wa.me/919910755865"><img src="whatsapp logo.png" alt=""></a></div><br>
    <div class="second"><a href="https://www.instagram.com/assetcompoundersacademy"><img src="Instagram-Icon.png" alt=""></a></div><br>
    <div class="third"><a href="https://www.facebook.com/assetcompounders"><img src="facebook.png" alt=""></a></div><br>
    <div class="fourth"><a href="https://youtube.com/@AssetCompoundersAcademy"><img src="youtube.png" alt=""></a></div>
    </div>

   
</body>
<script src="js/swiper-bundle.min.js"></script>

<script src="js/script.js"></script>
</html>