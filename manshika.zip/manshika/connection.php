<?php
error_reporting(0);
$servername = "localhost";
$usrname = "root";
$password = "";
$dbname = "responsiveform3";

$conn = mysqli_connect($servername,$usrname,$password,$dbname);

if($conn)
{
    // echo "connection ok";
}
else
{
    echo "connection faild";
}
?>