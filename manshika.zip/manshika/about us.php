<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        *{padding: 0; margin: 0; box-sizing: border-box;}
        header
        {
            width: 100%;
            height: 40vh;
            background-image: url('COMPOUND.JPG');
            background-size: cover;
            font-family: sans-serif;     
        }
        #menu #menu ul
{
  margin: 0;
  padding: 0;
  list-style: none;
}
#menu
{
    width: 900px;
    margin-left: 60vh;
    border-radius: 6px;
    padding-left:30PX;
    padding-top:5PX;
    padding-right: 0PX;
}
#menu:before,
#menu:after
{
    content: '';
    display: table;
}
#menu:after
{
    clear: both;
}
#menu li
{
   float: left;
   box-shadow: 1px 0 0 #444;
   position: relative;
}
#menu li li
{
   float: left;
   position: relative;
}
#menu a
{
    float: left;
    padding: 12px 20px;
    text-transform: uppercase;
    font-family: Baloo;
    text-decoration: none;
    color: white;

}

#menu li:hover > a
{
    color: #fafafa;
    background: #da0707;
}
#menu ul
{
    margin:  0 0 0;
    opacity: 0;
    visibility: hidden;
    position: absolute;
    top: 46px;
    left: 0;
    z-index: 1;
    background: #262626;
    border-radius: 3px;
    transition: all .3s ease-in-out;

}
#menu li:hover > ul
{
    opacity: 1;
    visibility: visible;
    margin: 0px;
}
#menu ul ul
{
   top: 0;
   left: 150px;
   margin: 0 0 0 50px;
}
#menu ul li
{
    float: none;
    display: block;
    border: 0;
    box-shadow: 0 1px 0 #111, 0 2px 0 #666;
}
#menu ul li :last-child
{
    box-shadow: none;
}
#menu ul a
{
    padding: 10px;
    width: 200px;
    display: block;
    white-space: nowrap;
    float: none;
    text-transform: uppercase;
}
#menu ul a:hover
{
    background-color: #e04818;
}
#menu ul li :first-child > a
{
  border-radius: 3px 3px 0 0;
}
        .active,menu ul li:hover
        {
            background-color: rgb(63, 17, 189);
            border-radius: 3px;
            right: 0vh;
            top: 0px;
        }
      
        h1
        {
            text-align: center;
            
            color: white;

        }
        p
        {
            text-align: center;
         
        }
        .row{
           background-color: rgba(6, 87, 107, 0.534);
            padding: 10px;
            margin: 0px;
        }
        .heding
        {
            color: rgb(6, 6, 143);
            text-align: center;
            font-weight: bold;
        }
        .sapna5
        {
            color: rgb(6, 6, 143);
        }
        .card-title
        {
            font-weight: bold;
            color: rgb(6, 6, 143);
        }
         
        .shalu
        {
            height: 300px;
            width: 550px;
            background-color: rgb(252, 247, 247);
            color: darkblue;
            margin: 30px;
            padding: 10px;
            position: absolute;
            left: 280px;
            top: 2000px;

        }
        video
        {
            width: 260px;
            height: 260px;
            margin: 20px;

        }
        .learn
        {
           
            text-decoration: none;
            transition: 0.4%;
        }
        .learn a:hover
        {
            background: transparent;
            border: 1px solid rgb(75, 18, 129);
        }

        .first
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .first img
       {
        width: 5vh;
        height: 30px;
        margin-left: -1vh;
       }
       .first img:hover
       {
        width: 8vh;
        height: 30px;
        animation-duration: 0s;
        margin-left: 1vh;

       }
       .second
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .second img
       {
        width: 4vh;
        height: 30px;
        margin-left: -1vh;
       }
       .second img:hover
       {
        width: 5vh;
        height: 30px;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .third
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .third img
       {
        width: 6vh;
        height: 30px;
        margin-left: -1.5vh;
       }
       .third img:hover
       {
        width: 8vh;
        height: 30;
       background-color: brown;
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .fourth
       {
        width: 5vh;
        height: 30px;
        margin-right: 0vh;
       }
      .fourth img
       {
        width: 6vh;
        height: 50px;
        margin-left: -2vh;
       }
       .fourth img:hover
       {
        width: 8vh;
        height: 30;
      
       margin-left: 1vh;
       animation-duration: -2s;

       }
       .popup
       {
        margin-top: -225vh;
        
       }
          
           </style>
</head>
<body>
  <header>
    <ul id="menu">
            
        <li><a href="index.php">Home</a></li>
        <li class="active"><a href="#">About</a></li>
        <li><a href="courses.php">Courses</a>
            <ul>
                <li><a href="logodigin.html">Graphic Desining</a>
                    <ul>
                        <li><a href="logodigin.html">logo design</a></li>
                        <li><a href="logodigin.html">Banner design</a></li>
                        <li><a href="logodigin.html">Poster design</a></li>
                        <li><a href="logodigin.html">logo design</a></li>
                    </ul>
                </li>
                <li>
                    <a href="logodigin.html">Web Design</a>
                    <ul>
                        <li><a href="logodigin.html">HTML</a></li>
                        <li><a href="logodigin.html">CSS</a></li>
                        <li><a href="logodigin.html">JAVA</a></li>
                        <li><a href="logodigin.html">PYTHON</a></li>
                    </ul>
                </li>

                <li>
                    <a href="logodigin.html">Marketing</a>
                    <ul>
                        <li><a href="logodigin.html">Email Marketing</a></li>
                        <li><a href="logodigin.html">Contact Marketing</a></li>
                        <li><a href="logodigin.html">Online Marketing</a></li>
                        <li><a href="logodigin.html">Ofline Marketing</a></li>
                    </ul>
                </li>

                <li>
                    <a href="logodigin.html">Branding</a>
                    <ul>
                        <li><a href="logodigin.html">Corporate Branding</a></li>
                        <li><a href="logodigin.html">Personal Branding</a></li>
                        <li><a href="logodigin.html">Place Branding</a></li>
                        <li><a href="logodigin.html">Digital Marketing</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li><a href="contact us.php">Contact</a></li>   
        <li class="learn"><a href="learn&earn.php">Learn & Earn</a></li>
        <li><a href="login.php">Login here</a></li>
    </ul>                          
    </header>  
<br>
<p>Founded by Rs <b>Agarwal and Rs </b></p>
<p><b>Goenka,</b>Emami Limited is one of</p>
<p>the most dynamic and fastest</p>
<p>growing FMCG companies in India</p>
    <div class="row">
        <p>                                      </p>
        <p>                                          </p>
        <p>                                         </p>      
        <h2 class="heding">What We Believe In</h2>
        <p>                                      </p>
        <p>                                          </p>
        <p>                                         </p>
        <p>                                      </p>
        <p>                                          </p>
        <p>                                         </p>
        <p>                                      </p>
        <div class="col-lg-3 border border-3 ;">
          <img src="icon5.png" class="card-img-top" alt="...">
         <p> Making products with</p>
         <p>passion to innovate</p>
         <p>through industry best</p>
         <p>standards of Research</p>
         <p>and Development</p>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="icon4.png" class="card-img-top" alt="...">
          <p>Focus on Natural and</p>
          <p>Ayurvedic formulations</p>
        </div>
        <div class="col-lg-3 border border-3;">
          <img src="icon3.png" class="card-img-top" alt="...">
          <p>Manufacturing</p>
          <p>Excellence</p>     
        </div>
        <div class="col-lg-3 border border-3;">
            <img src="icon2.png" class="card-img-top" alt="...">
            <p>Stringent Quality</p>
            <p>Control</p>
          </div>
</div>
<br><br>
<h1 class="sapna5">Our Story</h1>
<br><br>
<div class="container d-flex justify-content-evenly mt-5">
    <div class="col-lg-3 border border-3 ;">
      <img src="manshi.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <br>
        <h5 class="card-title">The Emami Group</h5>   
        <br>
        <p class="card-text">Emami Group has grown as a diversified conglomerate with leadership presence in varied sectors from FMCG, Paper & Packaging Board to Edible Oils & Food Manufacturing, Real Estate, Retail, Pharmacy Chain, Contemporary Art and more</p>
        <br>
         <a href="#">Know more</a>
      </div>
    </div>
    <div class="col-lg-3 border border-3;">
      <img src="manshi.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <br>
        <h5 class="card-title">Company Profile</h5>
        <br>
        <p class="card-text">Established in the ‘70s, we are a leading FMCG Company with a portfolio of over 450+ products, with footprints across the globe and employing over 3200 employees</p>
        <br><br><br>
        <a href="#">Know more</a>
      </div>
    </div>
    <div class="col-lg-3 border border-3;">
      <img src="manshi.jpeg" class="card-img-top" alt="...">
      <div class="card-body">
        <br>
        <h5 class="card-title">Vision & Mission</h5>
        <br>
        <p class="card-text"> We believe in making people healthy and beautiful, naturally, through quality and innovation in products and services…</p>
        <br><br><br><br>
        <a href="#">Know more</a>
      </div>
      
    </div>
    <div class="col-lg-3 border border-3;">
        <img src="manshi.jpeg" class="card-img-top" alt="...">
        <div class="card-body">
            <br>
          <h5 class="card-title">Our Journey</h5>
          <p class="card-text"> From a small office in the mid-seventies to a 3406 Cr* turnover, every step of our journey has been a learning experience towards success and achievement of our goals…</p>
          <br><br><br><br>
          <a href="#">Know more</a>
        </div>
        
      </div>
      
</div>

<video controls>
    <source src="VIDEO.mp4">
</video>
<br>
<div class="shalu">
    <h1 style="color: blue;">Emami Ltd. - A Value Driver</h1>
    <h1 style="color: blue;"> Organisation</h1>
    <p style="color: black;">The story of a ‘Made in India’ organization established in 1974 which today is one of the leading and fastest growing personal care and healthcare companies in India. A Company that cares for its communities and environment while ensuring its commitments to all stakeholders. This short film highlights about the Company’s values and commitment towards its human assets. Emami as a People’s organization has always valued talents and this film provides valuable insights, updates and information about our organization’s people-centric initiatives and culture aiming to showcase Emami Ltd. as a desired employer.</p>
</div>
<div class="popup">
    <div class="first"><a href="https://wa.me/919910755865"><img src="whatsapp logo.png" alt=""></a></div><br>
<div class="second"><a href="https://www.instagram.com/assetcompoundersacademy"><img src="Instagram-Icon.png" alt=""></a></div><br>
<div class="third"><a href="https://www.facebook.com/assetcompounders"><img src="facebook.png" alt=""></a></div><br>
<div class="fourth"><a href="https://youtube.com/@AssetCompoundersAcademy"><img src="youtube.png" alt=""></a></div>
</div>

</body>
</html>